let playlist =[{title: "Song 1", artist: "Artist A"}
]
playlist.forEach((element,index)=> {
    
    console.log(`id:${index+1} -- title by ${element.artist} song ${element.title}`);
});