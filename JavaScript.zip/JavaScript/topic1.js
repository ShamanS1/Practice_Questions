let bookTitle ="My Book";
let price = 300;
let quantity =4;
let taxRate = 12

let subtotal = price*quantity;
let Tax = subtotal*(12/100);
let Total = subtotal+Tax;

console.log(
    `You bought ${quantity} copies of "${bookTitle}".
Subtotal: ${subtotal}
Tax: ${Tax}
Total: ${Total}`
)