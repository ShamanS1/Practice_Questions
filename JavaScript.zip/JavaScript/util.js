export function toCelsius(f) {
  return ((f - 32) * 5) / 9;
}

export function toFahrenheit(c) {
  return (c * 9) / 5 + 32;
}
