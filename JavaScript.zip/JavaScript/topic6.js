<ul id="sidebar">
  <li class="category">Technology</li>
  <li class="category">Health</li>
  <li class="category">Travel</li>
  <li class="category">Finance</li>
</ul>


  categories.forEach((element) => {
    if (element.textContent.trim() === currentCategory) {
      element.style.fontWeight = "bold";
    } else {
      element.style.fontWeight = "normal"; 
    }
  });
document.body.innerHTML = `
  <h2>Categories</h2>
  <ul id="sidebar">
    <li class="category">Technology</li>
    <li class="category">Health</li>
    <li class="category">Travel</li>
    <li class="category">Finance</li>
  </ul>
`;

const currentCategory = "Travel"; 

const categories = document.querySelectorAll(".category");

categories.forEach((element) => {
  if (element.textContent.trim() === currentCategory) {
    element.style.fontWeight = "bold";
  } else {
    element.style.fontWeight = "normal";
  }
});

