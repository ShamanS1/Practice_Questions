
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

fetch("https://api.chucknorris.io/jokes/random")
  .then(res => {
    if (!res.ok) {
      throw new Error(`HTTP error! status: ${res.status}`);
    }
    return res.json();
  })
  .then(data => {
    console.log("Joke:", data.value);
  })
  .catch(err => {
    console.error("Failed to load joke:", err.message);
  });
