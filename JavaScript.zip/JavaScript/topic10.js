import { toCelsius, toFahrenheit } from './util.js';

console.log(toCelsius(100));
console.log(toFahrenheit(0));
