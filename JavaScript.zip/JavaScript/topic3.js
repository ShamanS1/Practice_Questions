const calculateTripDays=(startDate, endDate)=>{
    startDate=new Date("2025-12-12")
    endDate=new Date("2025-12-13");


    const tripDays =endDate-startDate;

    const diffdays =tripDays/(1000*60*60*24)

    console.log(diffdays);
}
calculateTripDays();

