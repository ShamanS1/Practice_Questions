let cart = [29.99, 15.5, 42.0, 8.25];

let total = 0;

for (let i = 0; i < cart.length; i++) {
    total += cart[i];
}

console.log(`Cart total: $${total.toFixed(2)}`);
