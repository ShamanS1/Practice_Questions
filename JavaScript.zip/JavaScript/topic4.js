const prompt = require("prompt-sync")();
let age = Number(prompt("Enter your age :"));

if (isNaN(age) || age < 0) {
    console.log("Please enter a valid age.");
} else if (age >= 18) {
    console.log("Watch all movies");
} else if (age >= 13) {
    console.log("Watch PG-13 movies");
} else {
    console.log("Watch kids movies");
}
