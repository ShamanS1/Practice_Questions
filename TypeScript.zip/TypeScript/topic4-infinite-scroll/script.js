var articles = [
    { title: "TypeScript Basics", content: "Introduction to TypeScript and why it’s useful for large-scale JavaScript applications." },
    { title: "Understanding Interfaces", content: "Learn how interfaces define object shapes and bring structure to your code." },
    { title: "Classes and Inheritance", content: "Explore object-oriented programming in TypeScript using classes and inheritance." },
    { title: "Generics in TypeScript", content: "Write flexible and reusable functions and components using generics." },
    { title: "Type Narrowing", content: "Improve type safety using techniques like `typeof` and `in` to narrow types." },
    { title: "Union and Intersection Types", content: "Understand how to combine multiple types for powerful type logic." },
    { title: "Enums in TypeScript", content: "Use enums to define a set of named constants in your code." },
    { title: "Modules and Namespaces", content: "Structure your codebase using modules and namespaces for maintainability." },
    { title: "Advanced Type Manipulation", content: "Use utility types like `Partial`, `Pick`, and `Record` effectively." },
    { title: "TypeScript with React", content: "Integrate TypeScript in a React project to get powerful type checking." },
    { title: "Decorators in TypeScript", content: "Explore experimental decorator support for meta-programming." },
    { title: "Type Assertion and Casting", content: "Guide to safely asserting types when you're sure of a value's shape." },
    { title: "Handling Errors", content: "Best practices for managing exceptions and errors in TypeScript." },
    { title: "Working with JSON and APIs", content: "How to fetch and type-check external API data in TypeScript." },
    { title: "Migrating from JS to TS", content: "A step-by-step guide to converting a JavaScript project to TypeScript." }
];
var container = document.getElementById('article-container');
var loader = document.getElementById('loader');
var currentIndex = 0;
var batchSize = 5;
var isLoading = false;
function renderArticles() {
    var end = Math.min(currentIndex + batchSize, articles.length);
    for (var i = currentIndex; i < end; i++) {
        var article = articles[i];
        var div = document.createElement('div');
        div.className = 'article';
        div.innerHTML = "<h2>".concat(article.title, "</h2><p>").concat(article.content, "</p>");
        container.appendChild(div);
    }
    currentIndex = end;
}
function loadMoreArticles() {
    if (isLoading || currentIndex >= articles.length)
        return;
    isLoading = true;
    loader.style.display = 'block';
    setTimeout(function () {
        renderArticles();
        isLoading = false;
        loader.style.display = 'none';
        // Trigger again if still not enough to scroll
        if (document.body.scrollHeight <= window.innerHeight) {
            loadMoreArticles();
        }
    }, 500);
}
function handleScroll() {
    var scrollTop = window.scrollY;
    var viewportHeight = window.innerHeight;
    var fullHeight = document.body.scrollHeight;
    if (scrollTop + viewportHeight >= fullHeight - 100) {
        loadMoreArticles();
    }
}
window.addEventListener('scroll', handleScroll);
// Initial load
renderArticles();
loadMoreArticles(); // In case content is shorter than screen
