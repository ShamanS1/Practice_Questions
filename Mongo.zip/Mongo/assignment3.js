const { MongoClient } = require("mongodb");
const uri = "mongodb://localhost:27017";
const client = new MongoClient(uri);

async function run() {
  await client.connect();
  const db = client.db("employeeDB");
  const users = db.collection("users");
  await users.insertOne({ name: "Nina", role: "Admin" });
  const allUsers = await users.find().toArray();
  console.log(allUsers);
  await client.close();
}

run();
